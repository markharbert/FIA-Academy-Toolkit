"use strict";

const API_BASE = "https://toolkit.fearlessmarketinglab.com";

// fetch() does not support data: URLs inside a service worker (throws TypeError).
// Use this helper instead wherever a data URL needs to become a Blob.
function dataUrlToBlob(dataUrl) {
  const [meta, b64] = dataUrl.split(",");
  const mime = meta.match(/:(.*?);/)[1];
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

// ── IndexedDB helpers (shared key-value store for large cross-context data) ───
// Same DB used by annotate.js. Works in both service worker and extension pages.
function idbOpenDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("fia-toolkit", 1);
    req.onupgradeneeded = e => e.target.result.createObjectStore("pending");
    req.onsuccess  = e => resolve(e.target.result);
    req.onerror    = () => reject(req.error);
  });
}
async function idbPut(key, value) {
  const db = await idbOpenDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("pending", "readwrite");
    tx.objectStore("pending").put(value, key);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror    = () => { db.close(); reject(tx.error); };
  });
}

// Convert Blob → data URL without fetch (safe in SW; uses small apply chunks).
async function blobToDataUrl(blob) {
  const arrayBuffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);
  const CHUNK = 1024; // well within V8's argument-count limit
  let binary = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
  }
  return `data:${blob.type};base64,${btoa(binary)}`;
}

// Store blob in session storage then open the annotation editor in a new tab.
// Each editor receives a unique handoff key so simultaneous captures cannot
// overwrite each other before their tabs finish loading.
async function openAnnotationTab(blob, title) {
  const dataUrl = await blobToDataUrl(blob);
  const captureId = crypto.randomUUID();
  await chrome.storage.session.set({
    [`pendingAnnotation:${captureId}`]: { dataUrl, title },
  });
  await chrome.tabs.create({
    url: `${chrome.runtime.getURL("annotate.html")}?capture=${encodeURIComponent(captureId)}`,
  });
}

// ─── Context menus ───────────────────────────────────────────────────────────

// Create the context menu items on install/update AND on every SW startup,
// so they're never missing if the SW was killed and restarted.
function ensureContextMenus() {
  chrome.contextMenus.create(
    { id: "fia-save-snippet", title: "Save to Swipe File", contexts: ["selection"] },
    () => { void chrome.runtime.lastError; } // silence "already exists" error
  );
  chrome.contextMenus.create(
    { id: "fia-link-vault", title: "Paste from Link Vault…", contexts: ["all"] },
    () => { void chrome.runtime.lastError; }
  );
}

chrome.runtime.onInstalled.addListener(ensureContextMenus);
chrome.runtime.onStartup.addListener(ensureContextMenus);
ensureContextMenus(); // also run immediately when the SW wakes

async function openLinkVaultPicker(tab) {
  const sourceTabId = tab?.id;
  const sourceWindowId = tab?.windowId;
  const pickerRequestId = crypto.randomUUID();

  // Only one picker should be active. Close a stale one before opening another.
  try {
    const existing = await chrome.storage.session.get("linkPickerContext");
    const oldWindowId = existing?.linkPickerContext?.pickerWindowId;
    if (Number.isInteger(oldWindowId)) await chrome.windows.remove(oldWindowId);
  } catch {
    // The previous picker may already be closed.
  }

  await chrome.storage.session.set({
    linkPickerContext: { sourceTabId, sourceWindowId, pickerRequestId, openedAt: Date.now() },
  });

  let left;
  let top;
  try {
    const sourceWindow = await chrome.windows.get(sourceWindowId);
    left = Math.round((sourceWindow.left ?? 0) + ((sourceWindow.width ?? 1200) - 380) / 2);
    top = Math.round((sourceWindow.top ?? 0) + ((sourceWindow.height ?? 800) - 560) / 2);
  } catch {
    // Chrome will choose a sensible position.
  }

  const picker = await chrome.windows.create({
    url: `${chrome.runtime.getURL("link-picker.html")}?request=${encodeURIComponent(pickerRequestId)}`,
    type: "popup",
    width: 380,
    height: 560,
    left,
    top,
    focused: true,
  });

  await chrome.storage.session.set({
    linkPickerContext: {
      sourceTabId,
      sourceWindowId,
      pickerWindowId: picker?.id,
      pickerRequestId,
      openedAt: Date.now(),
    },
  });
}

chrome.windows.onRemoved.addListener((windowId) => {
  chrome.storage.session.get("linkPickerContext").then(({ linkPickerContext }) => {
    if (linkPickerContext?.pickerWindowId === windowId) {
      return chrome.storage.session.remove("linkPickerContext");
    }
  }).catch(() => {});
});

// Cache the selection HTML sent by snippet-capture.js (content script).
// Using message passing is more reliable than calling chrome.storage from
// a content script directly, because sendMessage wakes the SW if needed.
// We key the cache by tabId so that concurrent right-clicks on different
// tabs cannot overwrite each other's selection HTML.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action === "cacheSnippetHtml" && msg.html) {
    const tabId = sender.tab?.id;
    if (!Number.isInteger(tabId)) return;
    // Store per-tab so a right-click on Tab B never clobbers Tab A's HTML.
    const key = `pendingSnippetHtml_${tabId}`;
    chrome.storage.session.set({ [key]: msg.html }).catch(() => {});
  }
});

// The picker copies the URL first, then asks the original page to insert it at
// the right-clicked field. Sites that block insertion still receive clipboard
// fallback, and the original browser window is brought back to the front.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action !== "pasteVaultLink" || typeof msg.url !== "string") return false;

  (async () => {
    const stored = await chrome.storage.session.get("linkPickerContext");
    const context = stored?.linkPickerContext || {};
    if (
      typeof msg.pickerRequestId !== "string" ||
      msg.pickerRequestId !== context.pickerRequestId
    ) {
      sendResponse({
        ok: false,
        inserted: false,
        error: "This Link Vault picker is no longer active.",
      });
      return;
    }

    let inserted = false;

    if (Number.isInteger(context.sourceTabId)) {
      // Bring the original page forward before asking its editor to insert.
      // Rich-text editors commonly reject execCommand while their tab is hidden.
      try {
        await chrome.tabs.update(context.sourceTabId, { active: true });
      } catch {}

      if (Number.isInteger(context.sourceWindowId)) {
        try {
          await chrome.windows.update(context.sourceWindowId, { focused: true });
        } catch {}
      }

      await swSleep(60);

      try {
        const response = await chrome.tabs.sendMessage(context.sourceTabId, {
          action: "insertVaultLink",
          url: msg.url,
        });
        inserted = response?.inserted === true;
      } catch {
        // Restricted pages and tabs closed since the menu click cannot receive messages.
      }
    } else if (Number.isInteger(context.sourceWindowId)) {
      try {
        await chrome.windows.update(context.sourceWindowId, { focused: true });
      } catch {}
    }

    await chrome.storage.session.remove("linkPickerContext");
    sendResponse({ ok: true, inserted });
  })().catch((err) => {
    console.error("[FIA] Link Vault paste failed:", err);
    sendResponse({ ok: false, inserted: false, error: err?.message || "Paste failed" });
  });

  return true;
});


// ─── Section capture: crop & store for popup ─────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action !== "sectionSelected") return;
  const { rect, dpr }  = msg;
  const sectionTabId   = sender.tab?.id;
  const sectionWinId   = sender.tab?.windowId;
  const tabTitle       = sender.tab?.title ?? "Section Screenshot";

  // captureVisibleTab requires windowId; <all_urls> in host_permissions makes it work on any site
  (async () => {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(sectionWinId, { format: "png" });

      const blob   = dataUrlToBlob(dataUrl);
      const bitmap = await createImageBitmap(blob);

      const cw = Math.max(1, Math.round(rect.width  * dpr));
      const ch = Math.max(1, Math.round(rect.height * dpr));
      const canvas = new OffscreenCanvas(cw, ch);
      const ctx    = canvas.getContext("2d");
      ctx.drawImage(
        bitmap,
        Math.round(rect.x * dpr), Math.round(rect.y * dpr), cw, ch,
        0, 0, cw, ch
      );
      bitmap.close(); // release GPU memory

      const croppedBlob = await canvas.convertToBlob({ type: "image/png" });

      await openAnnotationTab(croppedBlob, tabTitle);
    } catch (err) {
      console.error("[FIA SW] section crop error:", err);
      injectErrorToast(sectionTabId, `Capture failed: ${err.message}`);
    }
  })();
});

// ─── Full Page capture: native scroll-and-stitch ─────────────────────────────

function swSleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Page-level toasts (injected into the active tab) ─────────────────────────
function injectSaveToast(tabId) {
  if (!tabId) return;
  chrome.scripting.executeScript({ target: { tabId }, files: ["save-toast.js"] }).catch(() => {});
}

function injectErrorToast(tabId, message) {
  if (!tabId) return;
  chrome.scripting.executeScript({
    target: { tabId },
    func: (msg) => {
      const TOAST_ID = "__fia_save_toast__", STYLE_ID = "__fia_toast_style__";
      [TOAST_ID, STYLE_ID].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
      const style = document.createElement("style");
      style.id = STYLE_ID;
      style.textContent = "@keyframes _fia_in{from{opacity:0;transform:translateX(-50%) scale(.75)}to{opacity:1;transform:translateX(-50%) scale(1)}}@keyframes _fia_out{from{opacity:1;transform:translateX(-50%) scale(1)}to{opacity:0;transform:translateX(-50%) scale(.75)}}";
      (document.head || document.documentElement).appendChild(style);
      const toast = document.createElement("div");
      toast.id = TOAST_ID;
      toast.style.cssText = "position:fixed;top:28px;left:50%;transform:translateX(-50%);z-index:2147483647;background:linear-gradient(135deg,#e85d5d 0%,#b52b2b 100%);padding:11px 22px 11px 14px;border-radius:999px;box-shadow:0 8px 28px rgba(185,43,43,.45);display:flex;align-items:center;gap:10px;animation:_fia_in .4s cubic-bezier(.34,1.56,.64,1) both;pointer-events:none;font-family:-apple-system,BlinkMacSystemFont,sans-serif;user-select:none;-webkit-user-select:none";
      toast.innerHTML = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" style="flex-shrink:0"><circle cx="13" cy="13" r="12" fill="rgba(255,255,255,0.22)"/><path d="M8.5 8.5l9 9M17.5 8.5l-9 9" stroke="white" stroke-width="2.6" stroke-linecap="round"/></svg>`;
      const label = document.createElement("span");
      label.style.cssText = "color:#fff;font-size:14px;font-weight:650;white-space:nowrap";
      label.textContent = msg;
      toast.appendChild(label);
      (document.body || document.documentElement).appendChild(toast);
      setTimeout(() => { toast.style.animation = "_fia_out .32s ease-in both"; setTimeout(() => { toast.remove(); style.remove(); }, 350); }, 4000);
    },
    args: [message],
  }).catch(() => {});
}


// Full Page and Color Palette both scroll the source tab, hide fixed elements,
// and call captureVisibleTab. They must never run together on one tab.
const scrollCaptureInProgress = new Set();

function acquireScrollCapture(tabId, requestedTool) {
  if (!Number.isInteger(tabId)) {
    return { ok: false, error: "The page is no longer available." };
  }
  if (scrollCaptureInProgress.has(tabId)) {
    const error = "Another page scan is already running. Wait for it to finish before starting a new one.";
    return { ok: false, error };
  }
  scrollCaptureInProgress.add(tabId);
  return { ok: true, requestedTool };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action !== "startFullPageCapture") return false;
  const lock = acquireScrollCapture(msg.tabId, "full-page capture");
  if (!lock.ok) {
    sendResponse(lock);
    return false;
  }
  sendResponse({ ok: true }); // ack immediately; async work runs below
  handleFullPageCapture(msg.tabId, msg.title);
  return false;
});

// ─── Color Palette: full-page scroll capture + dominant-color analysis ────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action !== "startColorPaletteAnalysis") return false;
  const lock = acquireScrollCapture(msg.tabId, "color palette scan");
  if (!lock.ok) {
    sendResponse(lock);
    return false;
  }
  sendResponse({ ok: true }); // ack immediately
  handleColorPaletteAnalysis(msg.tabId, msg.sourceUrl, msg.sourceTitle);
  return false;
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "saveColorPalette") return false;

  (async () => {
    try {
      const stored = await chrome.storage.local.get(["apiKey"]);
      const key = stored.apiKey;
      if (!key) throw new Error("Not connected — please enter your API key.");

      if (!Array.isArray(msg.colors) || msg.colors.length !== 6) {
        throw new Error("The palette must contain exactly six colors.");
      }
      const colors = msg.colors.map(color => {
        if (typeof color !== "string" || !/^#[0-9A-Fa-f]{6}$/.test(color)) {
          throw new Error("The palette contains an invalid color.");
        }
        return color.toUpperCase();
      });
      const fonts = normalizePaletteFonts(msg.fonts);
      const content = JSON.stringify({ version: 1, colors, fonts });
      const sourceTitle = typeof msg.sourceTitle === "string" ? msg.sourceTitle.trim().slice(0, 120) : "";
      const fallbackTitle = new URL(msg.sourceUrl || "https://unknown").hostname;
      const title = `Color Palette — ${sourceTitle || fallbackTitle}`;
      const res = await fetch(`${API_BASE}/api/v1/swipe`, {
        method:  "POST",
        headers: { "Content-Type": "application/json", "X-API-Key": key },
        body:    JSON.stringify({ type: "palette", title, content, sourceUrl: msg.sourceUrl || "" }),
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`Server error ${res.status}${text ? `: ${text}` : ""}`);
      }
      sendResponse({ ok: true });
    } catch (err) {
      sendResponse({ ok: false, error: err.message || "Save failed" });
    }
  })();

  return true; // keep sendResponse alive for async
});

function normalizePaletteFonts(rawFonts) {
  if (!Array.isArray(rawFonts) || rawFonts.length > 8) {
    throw new Error("The palette fonts must contain at most eight families.");
  }
  return rawFonts.map((rawFont, familyIndex) => {
    if (!rawFont || typeof rawFont !== "object") {
      throw new Error(`Font ${familyIndex + 1} is invalid.`);
    }
    const family = typeof rawFont.family === "string"
      ? rawFont.family.trim().replace(/\s+/g, " ")
      : "";
    if (!family || family.length > 120 || /[\u0000-\u001F\u007F]/.test(family)) {
      throw new Error(`Font ${familyIndex + 1} has an invalid name.`);
    }
    if (!Array.isArray(rawFont.variants) || rawFont.variants.length < 1 || rawFont.variants.length > 8) {
      throw new Error(`Font ${family} must include between one and eight variants.`);
    }
    const variants = rawFont.variants.map((rawVariant, variantIndex) => {
      if (!rawVariant || typeof rawVariant !== "object") {
        throw new Error(`Font ${family} variant ${variantIndex + 1} is invalid.`);
      }
      const weight = typeof rawVariant.weight === "string" ? rawVariant.weight.trim() : "";
      const size = typeof rawVariant.size === "string" ? rawVariant.size.trim() : "";
      const count = rawVariant.count;
      if (!/^\d{1,4}$/.test(weight) || Number(weight) < 1 || Number(weight) > 1000) {
        throw new Error(`Font ${family} has an invalid weight.`);
      }
      if (!/^\d+(?:\.\d+)?px$/.test(size) || Number.parseFloat(size) <= 0 || Number.parseFloat(size) > 1000) {
        throw new Error(`Font ${family} has an invalid size.`);
      }
      if (!Number.isInteger(count) || count < 1 || count > 100_000) {
        throw new Error(`Font ${family} has an invalid usage count.`);
      }
      return { weight, size, count };
    });
    return { family, variants };
  });
}

// Read the actual computed typography used by visible, text-bearing elements.
// This complements screenshot-based color extraction without retaining page text.
async function extractPaletteFonts(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const MAX_FAMILIES = 8;
      const MAX_VARIANTS = 8;
      const rows = new Map();
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
      let element;
      let inspected = 0;
      while ((element = walker.nextNode()) && inspected < 6000) {
        inspected++;
        if (element.id?.startsWith("__fia_")) continue;
        const hasDirectText = [...element.childNodes].some(node =>
          node.nodeType === Node.TEXT_NODE && Boolean(node.textContent?.trim()),
        );
        if (!hasDirectText || element.getClientRects().length === 0) continue;
        const styles = window.getComputedStyle(element);
        if (styles.display === "none" || styles.visibility === "hidden") continue;

        const family = styles.fontFamily
          .split(",")[0]
          .trim()
          .replace(/^['"]|['"]$/g, "")
          .replace(/\s+/g, " ");
        const weight = /^\d+$/.test(styles.fontWeight)
          ? styles.fontWeight
          : styles.fontWeight === "bold" ? "700" : "400";
        const size = styles.fontSize;
        if (!family || !/^\d+(?:\.\d+)?px$/.test(size)) continue;

        const entry = rows.get(family) || { family, count: 0, variants: new Map() };
        entry.count++;
        const variantKey = `${weight}|${size}`;
        const variant = entry.variants.get(variantKey) || { weight, size, count: 0 };
        variant.count++;
        entry.variants.set(variantKey, variant);
        rows.set(family, entry);
      }

      return [...rows.values()]
        .sort((a, b) => b.count - a.count || a.family.localeCompare(b.family))
        .slice(0, MAX_FAMILIES)
        .map(font => ({
          family: font.family,
          variants: [...font.variants.values()]
            .sort((a, b) => b.count - a.count || Number(b.weight) - Number(a.weight) || Number(b.size.replace("px", "")) - Number(a.size.replace("px", "")))
            .slice(0, MAX_VARIANTS),
        }));
    },
  });
  return Array.isArray(result) ? result : [];
}

// Fold one screenshot into a bounded RGB histogram and release the decoded
// bitmap before the next viewport is captured.
async function addScreenshotToPaletteHistogram(dataUrl, buckets) {
  const MAX_SAMPLE_WIDTH = 160;
  let bitmap;
  try {
    const blob = dataUrlToBlob(dataUrl);
    bitmap = await createImageBitmap(blob);
    const w = bitmap.width;
    const h = bitmap.height;
    const sampleW = Math.max(1, Math.min(MAX_SAMPLE_WIDTH, w));
    const sampleH = Math.max(1, Math.round(h * (sampleW / w)));
    const canvas = new OffscreenCanvas(sampleW, sampleH);
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) throw new Error("Could not create the palette analysis canvas.");
    ctx.drawImage(bitmap, 0, 0, sampleW, sampleH);
    const data = ctx.getImageData(0, 0, sampleW, sampleH).data;
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] < 128) continue;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
      const bucket = buckets.get(key) || { count: 0, r: 0, g: 0, b: 0 };
      bucket.count++;
      bucket.r += r;
      bucket.g += g;
      bucket.b += b;
      buckets.set(key, bucket);
    }
  } finally {
    if (bitmap) bitmap.close();
  }
}

function extractDominantColors(buckets, nColors = 6) {
  if (buckets.size === 0) throw new Error("No pixels sampled from screenshots.");

  const ranked = [...buckets.values()]
    .map(bucket => ({
      count: bucket.count,
      rgb: [
        Math.round(bucket.r / bucket.count),
        Math.round(bucket.g / bucket.count),
        Math.round(bucket.b / bucket.count),
      ],
    }))
    .sort((a, b) => b.count - a.count);

  const selected = [];
  const selectedKeys = new Set();
  const distance = (a, b) => Math.sqrt(
    ((a[0] - b[0]) ** 2) + ((a[1] - b[1]) ** 2) + ((a[2] - b[2]) ** 2),
  );

  // Start with strong separation, then relax only as needed to reach six.
  for (const minimumDistance of [84, 64, 48, 32, 16, 0]) {
    for (const candidate of ranked) {
      const rgbKey = candidate.rgb.join(",");
      if (selectedKeys.has(rgbKey)) continue;
      if (selected.every(existing => distance(existing, candidate.rgb) >= minimumDistance)) {
        selected.push(candidate.rgb);
        selectedKeys.add(rgbKey);
        if (selected.length === nColors) break;
      }
    }
    if (selected.length === nColors) break;
  }

  // A truly monochrome page may not contain six sampled colors. Fill the rare
  // shortfall with nearby shades so the saved contract still has six unique values.
  const base = selected[0] || [128, 128, 128];
  for (let step = 1; selected.length < nColors; step++) {
    const sign = step % 2 === 0 ? -1 : 1;
    const amount = Math.ceil(step / 2) * 12 * sign;
    const shade = base.map(channel => Math.min(255, Math.max(0, channel + amount)));
    const shadeKey = shade.join(",");
    if (!selectedKeys.has(shadeKey)) {
      selected.push(shade);
      selectedKeys.add(shadeKey);
    }
  }

  return selected.slice(0, nColors).map(([r, g, b]) => {
    const hex = ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1).toUpperCase();
    return `#${hex}`;
  });
}

async function restoreColorPalettePageState(tabId, pageState) {
  if (!Number.isInteger(tabId)) return;
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (origX, origY) => {
      document.querySelectorAll("[data-fia-pal-orig-vis]").forEach(el => {
        el.style.visibility = el.dataset.fiaPalOrigVis;
        delete el.dataset.fiaPalOrigVis;
      });
      document.getElementById("__fia_pal_progress__")?.remove();
      if (Number.isFinite(origX) && Number.isFinite(origY)) window.scrollTo(origX, origY);
    },
    args: [pageState?.origX ?? null, pageState?.origY ?? null],
  });
}

async function handleColorPaletteAnalysis(tabId, sourceUrl, sourceTitle) {
  const MAX_PALETTE_STRIPS = 120;
  let pageState = null;
  try {
    // Typography comes directly from the page's rendered DOM, not screenshots.
    // If a page blocks style inspection, the color palette still succeeds.
    const fonts = await extractPaletteFonts(tabId).catch(err => {
      console.warn("[FIA SW] palette font extraction failed:", err);
      return [];
    });

    // 1. Read page geometry (same approach as full-page capture)
    const [{ result: dims }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({
        scrollH: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight ?? 0),
        vpH:     window.innerHeight,
        vpW:     window.innerWidth,
        origX:   window.scrollX,
        origY:   window.scrollY,
      }),
    });
    const { scrollH, vpH, vpW, origX, origY } = dims;
    pageState = { origX, origY };

    if (!vpH || !vpW) throw new Error("Viewport dimensions are zero.");
    const totalSteps = Math.ceil(scrollH / vpH);
    if (totalSteps > MAX_PALETTE_STRIPS) {
      throw new Error(`This page is too long to scan safely (more than ${MAX_PALETTE_STRIPS} screens).`);
    }

    const { windowId } = await chrome.tabs.get(tabId);

    // 2. Inject progress banner
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const el = document.createElement("div");
        el.id = "__fia_pal_progress__";
        el.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#1a1a2e;color:#fff;font:600 13px -apple-system,sans-serif;padding:9px 18px;text-align:center;pointer-events:none";
        el.textContent = "FIA Toolkit: scanning page colors…";
        document.documentElement.appendChild(el);
      },
    });

    // 3. Scroll to top
    await chrome.scripting.executeScript({ target: { tabId }, func: () => window.scrollTo(0, 0) });
    await swSleep(250);

    // 4. Capture each strip (same safeguards as full-page capture)
    const buckets = new Map();

    for (let i = 0; i < totalSteps; i++) {
      const scrollTop = (i === totalSteps - 1) ? Math.max(0, scrollH - vpH) : i * vpH;

      await chrome.scripting.executeScript({
        target: { tabId }, func: (y) => window.scrollTo(0, y), args: [scrollTop],
      });
      await swSleep(600);

      // Hide fixed/sticky top elements after the first strip
      if (i === 1) {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            document.querySelectorAll("*").forEach(el => {
              if (el.id && el.id.startsWith("__fia_")) return;
              const st  = window.getComputedStyle(el);
              const pos = st.position;
              if (pos !== "fixed" && pos !== "sticky") return;
              const rect = el.getBoundingClientRect();
              if (rect.height <= 0 || rect.width <= 0) return;
              let hide = false;
              if (pos === "fixed") {
                hide = rect.top >= -5 && rect.top < window.innerHeight * 0.35;
              } else {
                const topPx = parseFloat(st.top);
                hide = !isNaN(topPx) && topPx <= 20;
              }
              if (hide) {
                el.dataset.fiaPalOrigVis = el.style.visibility;
                el.style.setProperty("visibility", "hidden", "important");
              }
            });
          },
        });
      }

      // Hide progress banner before capture
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const el = document.getElementById("__fia_pal_progress__");
          if (el) el.style.visibility = "hidden";
        },
      });
      await swSleep(80);

      const [activeBeforeCapture] = await chrome.tabs.query({ active: true, windowId });
      if (activeBeforeCapture?.id !== tabId) {
        throw new Error("Keep the source tab active until the color scan finishes.");
      }
      const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
      const [activeAfterCapture] = await chrome.tabs.query({ active: true, windowId });
      if (activeAfterCapture?.id !== tabId) {
        throw new Error("Keep the source tab active until the color scan finishes.");
      }
      await addScreenshotToPaletteHistogram(dataUrl, buckets);

      // Restore progress banner
      await chrome.scripting.executeScript({
        target: { tabId },
        func: (cur, tot) => {
          const el = document.getElementById("__fia_pal_progress__");
          if (el) {
            el.style.visibility = "visible";
            el.textContent = `FIA Toolkit: scanning page colors… ${cur} / ${tot}`;
          }
        },
        args: [i + 1, totalSteps],
      });
    }

    // 5. Restore the page before the more expensive image analysis runs.
    await restoreColorPalettePageState(tabId, pageState);

    // 6. Select six distinct dominant colors from the accumulated histogram.
    const colors = extractDominantColors(buckets, 6);

    // 7. Inject the overlay content script, then send it the colors.
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["color-palette.js"],
    });
    await chrome.tabs.sendMessage(tabId, {
      action:    "showColorPalette",
      colors,
      fonts,
      sourceUrl: sourceUrl || "",
      sourceTitle: sourceTitle || "",
    });

  } catch (err) {
    console.error("[FIA SW] color palette error:", err);
    await restoreColorPalettePageState(tabId, pageState).catch(() => {});
    // Inject color-palette.js to show the failure toast
    chrome.scripting.executeScript({ target: { tabId }, files: ["color-palette.js"] })
      .then(() => chrome.tabs.sendMessage(tabId, {
        action: "colorPaletteFailed",
        error:  `Color Palette failed: ${err.message}`,
      }))
      .catch(() => injectErrorToast(tabId, `Color Palette failed: ${err.message}`));
  } finally {
    scrollCaptureInProgress.delete(tabId);
  }
}

// Hard limits for full-page canvas to avoid OOM / silent blank-canvas failures.
// Chrome's maximum canvas dimension is platform-dependent but 16 384 px is safe
// on all supported platforms; we use a slightly lower value for headroom.
const FULL_PAGE_MAX_HEIGHT_PX = 15000;
const FULL_PAGE_MAX_STRIPS    = 60;
const FULL_PAGE_MAX_WIDTH_PX  = 6000;
const FULL_PAGE_MAX_PIXELS    = 40_000_000;

async function handleFullPageCapture(tabId, title) {
  // Strip-based capture → annotate-editor approach:
  // Each strip is scaled to logical-pixel resolution (DPR=1) via OffscreenCanvas,
  // stored as data URLs in IndexedDB (no 10 MB session-storage cap), then the
  // annotation editor opens and stitches them into one scrollable canvas.

  let origX = 0, origY = 0;
  try {
    // 1. Read page geometry
    const [{ result: dims }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({
        scrollH: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight ?? 0),
        vpH:     window.innerHeight,
        vpW:     window.innerWidth,
        origX:   window.scrollX,
        origY:   window.scrollY,
      }),
    });
    ({ origX, origY } = dims);
    const { scrollH, vpH, vpW } = dims;

    // Guard: degenerate viewport (some iframes / SPAs) — avoids Math.ceil(x/0) = Infinity.
    if (!Number.isFinite(vpH) || !Number.isFinite(vpW) || vpH <= 0 || vpW <= 0) {
      throw new Error("Capture aborted: viewport dimensions are invalid.");
    }

    // Guard: canvas memory limit — Chrome silently produces a blank canvas above
    // ~32 768 px in either dimension. Fail fast with a clear message instead.
    if (scrollH > FULL_PAGE_MAX_HEIGHT_PX) {
      throw new Error(
        `Page is too tall to capture (${scrollH}px). ` +
        `Maximum supported height is ${FULL_PAGE_MAX_HEIGHT_PX}px.`
      );
    }
    if (vpW > FULL_PAGE_MAX_WIDTH_PX) {
      throw new Error(
        `Page is too wide to capture (${vpW}px). ` +
        `Maximum supported width is ${FULL_PAGE_MAX_WIDTH_PX}px.`
      );
    }
    if (scrollH * vpW > FULL_PAGE_MAX_PIXELS) {
      throw new Error(
        `Page is too large to capture safely (${Math.round((scrollH * vpW) / 1_000_000)} million pixels). ` +
        `Maximum is ${Math.round(FULL_PAGE_MAX_PIXELS / 1_000_000)} million pixels.`
      );
    }
    const totalStepsCheck = Math.ceil(scrollH / vpH);
    if (totalStepsCheck > FULL_PAGE_MAX_STRIPS) {
      throw new Error(
        `Page requires too many capture strips (${totalStepsCheck}). ` +
        `Maximum is ${FULL_PAGE_MAX_STRIPS}.`
      );
    }

    // 2. Get windowId for captureVisibleTab
    const { windowId } = await chrome.tabs.get(tabId);

    // 3. Inject progress banner
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const el = document.createElement("div");
        el.id = "__fia_progress__";
        el.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#1a1a2e;color:#fff;font:600 13px -apple-system,sans-serif;padding:9px 18px;text-align:center;pointer-events:none";
        el.textContent = "FIA Toolkit: capturing full page…";
        document.documentElement.appendChild(el);
      },
    });

    // 4. Scroll to top
    await chrome.scripting.executeScript({ target: { tabId }, func: () => window.scrollTo(0, 0) });
    await swSleep(250);

    // 5. Capture each strip
    const totalSteps = Math.ceil(scrollH / vpH);
    const strips     = [];

    for (let i = 0; i < totalSteps; i++) {
      // Last step flushes to the exact bottom so no content is clipped
      const scrollTop = (i === totalSteps - 1) ? Math.max(0, scrollH - vpH) : i * vpH;

      await chrome.scripting.executeScript({
        target: { tabId }, func: (y) => window.scrollTo(0, y), args: [scrollTop],
      });
      // Chrome enforces MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND (≈ 2/s).
      // 600 ms gives scroll time to settle and keeps us comfortably under the limit.
      await swSleep(600);

      // After strip 0 is captured we hide fixed/sticky top elements so they don't
      // repeat in every subsequent strip. Strip 0 shows them naturally (correct).
      if (i === 1) {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            document.querySelectorAll("*").forEach(el => {
              if (el.id && el.id.startsWith("__fia_")) return;
              const st  = window.getComputedStyle(el);
              const pos = st.position;
              if (pos !== "fixed" && pos !== "sticky") return;
              const rect = el.getBoundingClientRect();
              if (rect.height <= 0 || rect.width <= 0) return;
              let hide = false;
              if (pos === "fixed") {
                hide = rect.top >= -5 && rect.top < window.innerHeight * 0.35;
              } else {
                const topPx = parseFloat(st.top);
                hide = !isNaN(topPx) && topPx <= 20;
              }
              if (hide) {
                el.dataset.fiaOrigVis = el.style.visibility;
                el.style.setProperty("visibility", "hidden", "important");
              }
            });
          },
        });
      }

      // Hide the progress banner so it doesn't bake into the captured strip,
      // then sleep briefly so the browser repaints before the screenshot fires.
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const el = document.getElementById("__fia_progress__");
          if (el) el.style.visibility = "hidden";
        },
      });
      await swSleep(80); // repaint gap — without this the banner can still be visible in the capture

      // Capture at device DPR and store the raw data URL directly.
      // OffscreenCanvas.convertToBlob() is unreliable in extension SW contexts;
      // the annotate editor uses 9-arg drawImage to handle DPR scaling instead.
      const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
      strips.push(dataUrl);

      // Restore the progress banner and update its counter.
      await chrome.scripting.executeScript({
        target: { tabId },
        func: (cur, tot) => {
          const el = document.getElementById("__fia_progress__");
          if (el) {
            el.style.visibility = "visible";
            el.textContent = `FIA Toolkit: capturing full page… ${cur} / ${tot}`;
          }
        },
        args: [i + 1, totalSteps],
      });
    }

    // 6. Restore hidden fixed/sticky elements now that capture is complete
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        document.querySelectorAll("[data-fia-orig-vis]").forEach(el => {
          el.style.visibility = el.dataset.fiaOrigVis;
          delete el.dataset.fiaOrigVis;
        });
      },
    });

    // 7. Restore scroll position
    await chrome.scripting.executeScript({
      target: { tabId }, func: (x, y) => window.scrollTo(x, y), args: [origX, origY],
    });

    // 7. Remove progress banner
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => { const el = document.getElementById("__fia_progress__"); if (el) el.remove(); },
    });

    // 8. Store strips under this capture's unique handoff key.
    const captureId = crypto.randomUUID();
    await idbPut(
      `pendingFullPage:${captureId}`,
      { strips, title: title || "Full Page", scrollH, vpH, vpW },
    );

    // 9. Open annotation editor — it will stitch + save the full image
    await chrome.tabs.create({
      url: `${chrome.runtime.getURL("annotate.html")}?capture=${encodeURIComponent(captureId)}`,
    });

  } catch (err) {
    console.error("[FIA SW] full page capture error:", err);
    // Restore fixed/sticky elements, scroll position, and remove progress banner.
    chrome.scripting.executeScript({
      target: { tabId },
      func: (ox, oy) => {
        document.querySelectorAll("[data-fia-orig-vis]").forEach(el => {
          el.style.visibility = el.dataset.fiaOrigVis;
          delete el.dataset.fiaOrigVis;
        });
        const banner = document.getElementById("__fia_progress__");
        if (banner) banner.remove();
        // Restore scroll position so the page doesn't stay pinned at the top/bottom.
        if (Number.isFinite(ox) && Number.isFinite(oy)) window.scrollTo(ox, oy);
      },
      args: [origX, origY],
    }).catch(() => {});
    injectErrorToast(tabId, `Capture failed: ${err.message}`);
  } finally {
    scrollCaptureInProgress.delete(tabId);
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "fia-link-vault") {
    try {
      await openLinkVaultPicker(tab);
    } catch (err) {
      console.error("[FIA] Link Vault picker failed:", err);
      injectErrorToast(tab?.id, "Could not open Link Vault");
    }
    return;
  }

  if (info.menuItemId !== "fia-save-snippet") return;
  const text      = info.selectionText ?? "";
  const sourceUrl = tab?.url ?? "";
  const title     = (tab?.title ?? "Snippet").substring(0, 120);
  const tabId     = tab?.id;

  const stored = await chrome.storage.local.get(["apiKey"]);
  const key = stored.apiKey;
  if (!key) {
    // No API key — surface an error instead of silently doing nothing.
    injectErrorToast(tabId, "Snippet not saved — please connect your API key first.");
    return;
  }

  // snippet-capture.js stashes the selection HTML in session storage at the
  // moment of right-click (before the selection is cleared by the menu click).
  // Read it here and clear it so it doesn't bleed into the next snippet.
  // The key is tab-scoped so concurrent right-clicks on different tabs are safe.
  let content = text;
  try {
    const sessionKey = `pendingSnippetHtml_${tabId}`;
    const session = await chrome.storage.session.get(sessionKey);
    const html = session?.[sessionKey];
    if (html && html.trim()) {
      content = html;
      await chrome.storage.session.remove(sessionKey);
    }
  } catch {
    // Session storage unavailable — plain text fallback is fine
  }

  try {
    const res = await fetch(`${API_BASE}/api/v1/swipe`, {
      method:  "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": key },
      body:    JSON.stringify({ type: "snippet", title, content, sourceUrl }),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`Server error ${res.status}${body ? `: ${body}` : ""}`);
    }
    injectSaveToast(tabId);
  } catch (err) {
    console.error("[FIA] Snippet save failed:", err.message);
    injectErrorToast(tabId, `Snippet not saved: ${err.message}`);
  }
});
// This public key is safe to embed — it is designed to be shared with clients.
const VAPID_PUBLIC_KEY = "BPdIbvBytx7rxn5z3S3QJ2vI0GhB-PTDrtKpnpyyMa52g_nGrS7MCxYnUpbXEUMGPosBYYFydnRbXFm3rmnRBZE";

// ─── Push subscription ────────────────────────────────────────────────────────
function urlBase64ToUint8Array(b64) {
  const pad = "=".repeat((4 - (b64.length % 4)) % 4);
  const base64 = (b64 + pad).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

async function subscribeToPush(apiKey) {
  try {
    const existing = await self.registration.pushManager.getSubscription();
    if (existing) await existing.unsubscribe();

    const subscription = await self.registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
    });

    await fetch(`${API_BASE}/api/extension/subscribe`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": apiKey },
      body: JSON.stringify(subscription.toJSON()),
    });

    console.log("[FIA] Push subscription registered");
    return { success: true };
  } catch (err) {
    console.warn("[FIA] Push subscription failed:", err.message);
    return { success: false, error: err.message };
  }
}

async function unsubscribeFromPush(apiKey) {
  try {
    const sub = await self.registration.pushManager.getSubscription();
    if (sub) {
      await sub.unsubscribe();
      await fetch(`${API_BASE}/api/extension/unsubscribe`, {
        method: "DELETE",
        headers: { "X-API-Key": apiKey },
      });
    }
  } catch (err) {
    console.warn("[FIA] Unsubscribe failed:", err.message);
  }
}

// ─── Suspended-membership auto-recovery (chrome.alarms) ──────────────────────

const SUSPENDED_ALARM      = "fia-suspended-check";
const SUSPENDED_CHECK_MINS = 5;

// Fires every 5 minutes while the member is suspended.
// Survives popup close because it runs in the service worker.
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== SUSPENDED_ALARM) return;
  checkMembershipAlarm();
});

async function checkMembershipAlarm() {
  const { apiKey, suspended } = await chrome.storage.local.get(["apiKey", "suspended"]);
  if (!apiKey || !suspended) {
    // State no longer requires background checking — cancel the alarm.
    chrome.alarms.clear(SUSPENDED_ALARM);
    return;
  }

  // Record when this check cycle began so the popup can compute the real remainder.
  await chrome.storage.local.set({ lastSuspendedCheckAt: Date.now() });

  try {
    const res = await fetch(`${API_BASE}/api/v1/membership/check`, {
      method: "POST",
      headers: { "X-API-Key": apiKey, "Content-Type": "application/json" },
    });
    if (!res.ok) return; // Silent — will retry on next alarm
    const data = await res.json();
    if (!data.enrolled) return; // Still inactive — will retry on next alarm

    // ── Membership restored ──
    chrome.alarms.clear(SUSPENDED_ALARM);
    await chrome.storage.local.set({ suspended: false });

    // Tell the popup if it is currently open (throws if popup is closed — that's fine).
    try {
      await chrome.runtime.sendMessage({ type: "MEMBERSHIP_RESTORED" });
    } catch {}

    // Show a system notification so the member knows even when the popup is closed.
    try {
      chrome.notifications.create("fia-membership-restored", {
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: "FIA Toolkit — Access Restored 🎉",
        message: "Your membership is active again. Open the extension to continue.",
        priority: 2,
      });
    } catch {}
  } catch {
    // Network error — silent, will retry on next alarm
  }
}

// ─── Runtime messages from popup ─────────────────────────────────────────────
// Uses chrome.runtime.onMessage (the correct MV3 extension messaging API).
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const { type, apiKey } = message || {};

  if (type === "START_SUSPENDED_CHECK") {
    chrome.storage.local.set({ suspended: true, lastSuspendedCheckAt: Date.now() }).then(() =>
      chrome.alarms.create(SUSPENDED_ALARM, { periodInMinutes: SUSPENDED_CHECK_MINS })
    );
    sendResponse({ ok: true });
    return false;
  }

  if (type === "STOP_SUSPENDED_CHECK") {
    chrome.storage.local.set({ suspended: false }).then(() =>
      chrome.alarms.clear(SUSPENDED_ALARM)
    );
    sendResponse({ ok: true });
    return false;
  }
});

// ─── Event listeners ──────────────────────────────────────────────────────────

// Messages from popup (push subscription — kept on the existing web-SW channel
// used by the rest of the extension push flow).
self.addEventListener("message", (event) => {
  const { type, apiKey } = event.data || {};
  if (type === "SUBSCRIBE_PUSH") {
    event.waitUntil(subscribeToPush(apiKey));
  }
  if (type === "UNSUBSCRIBE_PUSH") {
    event.waitUntil(unsubscribeFromPush(apiKey));
  }
});

// Incoming push notification
self.addEventListener("push", (event) => {
  let data = { title: "FIA Toolkit", body: "" };
  try { data = { ...data, ...event.data.json() }; } catch (_) {}

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "icons/icon128.png",
      badge: "icons/icon48.png",
      tag: "fia-toolkit-broadcast",
      renotify: true,
    })
  );
});

// Notification click — open the toolkit
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((windowClients) => {
        const existing = windowClients.find((c) => c.url.startsWith(API_BASE));
        if (existing) return existing.focus();
        return clients.openWindow(API_BASE);
      })
  );
});
